package breadcrumbs.annotation;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import breadcrumbs.scope.BreadCrumbsScopeEnum;

@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface BreadCrumbs {

	/**
     * Indique que le prochain passage dans le filtre recalcul le breadCrumbs
     * 
     * @return {@link Boolean}
     */
    boolean reset() default false;

    /**
     * Surcharge le actionName injecté dans le Filtre
     * Surcharge egalement toutes les autres options de cette classe
     * 
     * @return {@link String}
     */
    String overrideActionName() default "";

    /**
     * Surcharge le controllerName injecté dans le Filtre
     * Surcharge egalement toutes les autres options de cette classe
     * 
     * @return {@link String}
     */
    String overrideControllerName() default "";

    /**
     * Indique au {@link BreadCrumbFilters} le nom
     * du parametre contenant la surcharge du nom de l'action
     * Important : ce parametre est testé avant actionNameInSession
     * si actionParameterName != "" alors {@link BreadCrumbFilters} ne regardera pas la valeur
     * actionNameInSession()
     * 
     * @return {@link String} le nom du parametre actionName
     */
    String actionParameterName() default "";

    /**
     * Indique au {@link BreadCrumbFilters} le nom
     * du parametre contenant la surcharge du nom de l'action
     * Important : ce parametre est testé avant controllerNameInSession
     * si controllerParameterName != "" alors {@link BreadCrumbFilters} ne regardera pas la valeur
     * controllerNameInSession()
     * 
     * @return {@link String} le nom du parametre controllerName
     */
    String controllerParameterName() default "";

    /**
     * Indique au {@link BreadCrumbFilters} que l'"actionName"
     * se trouve en session dans l'espace breadcrumbs.actionName
     * 
     * @return {@link Boolean}
     */
    boolean actionNameInSession() default false;

    /**
     * Indique au {@link BreadCrumbFilters} que le "controllerName"
     * se trouve en session dans l'espace breadcrumbs.controllerName
     * 
     * @return {@link Boolean}
     */
    boolean controllerNameInSession() default false;
    
    
    
    /**
     * The scope ti retrieve actionName and controlerName
     * @return int
     */
    BreadCrumbsScopeEnum scope() default BreadCrumbsScopeEnum.STATIC;
    
    /**
     * Delete entire breadcrumbs definition and rebuild 
     * @return String[]
     */
    String[] overridePath(); 
    
    /**
     * Indique au {@link BreadCrumbFilters} que l'"actionName"
     * se trouve en session dans l'espace breadcrumbs.actionName
     * 
     * @return {@link Boolean}
     */
    String actionName() default "";

    /**
     * Indique au {@link BreadCrumbFilters} que le "controllerName"
     * se trouve en session dans l'espace breadcrumbs.controllerName
     * 
     * @return {@link Boolean}
     */
    String controllerName() default "";
    
}
