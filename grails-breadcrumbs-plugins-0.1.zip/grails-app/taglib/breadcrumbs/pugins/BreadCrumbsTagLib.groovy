package breadcrumbs.pugins

class BreadCrumbsTagLib {
	
	static namespace = 'crumbs'
	
	def breadCrumbsServiceProxy
	
	/**
	 *
	 */
	def breadcrumbs = {attrs, body ->
		def breadcrumbs  = breadCrumbsServiceProxy.getAndDestroyBreadCrumbsPath()
		out << render(plugin: 'breadcrumbs-plugins', template: "/tpl/breadcrumbs", model: [breadcrumbs: breadcrumbs])
	}
}
