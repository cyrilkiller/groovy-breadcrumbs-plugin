
grails.resources.modules = {
	
	breadcrumbs {
		resource url: 'lib/breadcrumbs/less/breadcrumbs.less'
	}
}