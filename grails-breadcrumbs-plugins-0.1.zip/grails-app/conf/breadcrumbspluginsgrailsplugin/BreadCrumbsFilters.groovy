package breadcrumbspluginsgrailsplugin

import java.lang.reflect.Method

import org.apache.commons.lang.StringUtils
import org.springframework.context.i18n.LocaleContextHolder as LCH

import breadcrumbs.BreadCrumbsService;
import breadcrumbs.annotation.BreadCrumbs

class BreadCrumbsFilters {

	/** i18n service */
	def messageSource
	/** Service as proxy {@link BreadCrumbsService} */
	def breadCrumbsServiceProxy
	/** The global grails application*/
	def grailsApplication
//	/***/
	def menuDefinitionServiceProxy
	
    def filters = {
        all(controller:'*', action:'*') {
            before = {
				//Exclusion des requete Ajax
				if(!request.xhr){
					checkBreadCrumbs(controllerName, actionName, params, session)
				}
            }
            after = { Map model ->
				if(!request.xhr){
					BreadCrumbs bm = null
					/* Retrieve whether the target method is annoted */
					if(controllerName != null && actionName != null){
						Class clazz = breadCrumbsServiceProxy.retrieveArtifact("Controller", controllerName).clazz
						if(clazz != null){
							Method m
							
							try{
								m = clazz.getMethod(actionName, null)
							}catch(NoSuchMethodException e){/* No method !!! Dynamic Scaffolding ... */}
							
							if(m != null && m.isAnnotationPresent(BreadCrumbs.class)){
								bm = m.getAnnotation(BreadCrumbs.class)
								
								//Si oui on supprime le bradcrumbs en session
								session["breadcrumbs"].path = null
								
							}
						}
					}
					/*
					 * Define action, controller name
					 */
					if(bm != null && breadCrumbsServiceProxy.validate(bm)){

						String ctrl = controllerName
						String act = actionName

						/* Retrieve params from scope */
						def parameters = breadCrumbsServiceProxy.findOverrideParams(bm)
						
						/* if actionName is define */
						if(parameters["actionName"]){
							act = parameters["actionName"]
						}
						
						/* if controllerName is define */
						if(parameters["controllerName"]){
							ctrl = parameters["controllerName"]
						}

						checkBreadCrumbs(ctrl, act, params, session)

					}
				}
            }
            afterView = { Exception e ->
				//Nothing here
            }
        }
    }
	
	
	def checkBreadCrumbs(ctrl, act, prs, sess){
		
			ctrl = StringUtils.lowerCase(ctrl)
			act = StringUtils.lowerCase(act)
	
			if(sess["breadcrumbs"] == null){
				sess["breadcrumbs"] = [:]
			}
	
			if(sess["breadcrumbs"].path == null){
				def path = []
				
				try {
					/* Application service */
					def menus = menuDefinitionServiceProxy.loadMenuDefinition()				
					path = breadCrumbsServiceProxy.retrieveItemMenu(menus, act, ctrl, prs);
				}catch(Exception e){
					/* no service MenuDefinitionService as proxy is provide */
				}  
				
				//Ajout "Accueil" dans le cas ou on arrive sur la page
				if(path == null || path.size() == 0){
					path << messageSource.getMessage('breadcrumbs.home.label', null, LCH.getLocale())
				}
				
				sess["breadcrumbs"].path = path
			}
	}
}
